<?php
$error = false;
if (isset($request->auth)) {
    $_SESSION['login'] = $request->login?? '';
    if (isset($request->password) && is_string($request->password)) {
        $_SESSION['password'] = md5($request->password.SECRET);
    }
    $error = true;
}

if (isset($request->logout)) {
    unset($_SESSION['login']);
    unset($_SESSION['password']);
    $error = false;
    print_r($_SERVER);
    $path = parse_url($_SERVER['REQUEST_URI']);
    print_r($path);
    parse_str($path['query']?? '', $query_array);
    unset($query_array['logout']);
    $new_query = http_build_query($query_array);
    $new_url = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['SERVER_NAME'].'/'.$path['host'].$path['path'].'?'.$new_query;
    echo $new_url;
    header("Location: $new_url");
}

$login = $_SESSION['login']?? false;
$password = $_SESSION['password']?? false;
$auth_user = $db->getRowByWhere('users', '`login` = ? AND `password` = ?', [$login, $password]);
if ($auth_user) $error = false;
// print_r($_REQUEST);