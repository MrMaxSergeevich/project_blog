-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Хост: MySQL-8.0
-- Время создания: Ноя 25 2025 г., 17:08
-- Версия сервера: 8.0.35
-- Версия PHP: 8.1.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `db_blog`
--

-- --------------------------------------------------------

--
-- Структура таблицы `bl_comments`
--

CREATE TABLE `bl_comments` (
  `id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `post_id` int UNSIGNED DEFAULT NULL,
  `comment` varchar(255) NOT NULL,
  `time_comment` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `bl_comments`
--

INSERT INTO `bl_comments` (`id`, `user_id`, `post_id`, `comment`, `time_comment`) VALUES
(1, 1, 1, 'Комментарий 1', 1763969823),
(2, 1, 1, 'Комментарий 2', 1763969831),
(3, 2, 1, 'Комментарий 3', 1763969834),
(4, 1, 1, 'Комментарий 4', 1763969836),
(5, 2, 2, 'Комментарий 5', 1763969842),
(6, 2, 2, 'Комментарий 6', 1763969846),
(7, 1, 2, 'Комментарий 7', 1763969847),
(8, 2, 1, 'Комментарий 8', 1763969848),
(9, 1, 1, 'Комментарий 9', 1763969849),
(10, 1, 2, 'Комментарий 10', 1763969853),
(11, 1, 1, 'Комментарий 11', 1763969859);

-- --------------------------------------------------------

--
-- Структура таблицы `bl_posts`
--

CREATE TABLE `bl_posts` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `discription` text NOT NULL,
  `time_public` int UNSIGNED NOT NULL,
  `comment_id` int UNSIGNED DEFAULT NULL,
  `user_id` int UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `bl_posts`
--

INSERT INTO `bl_posts` (`id`, `title`, `discription`, `time_public`, `comment_id`, `user_id`) VALUES
(1, 'Первый пост', 'Текст первого поста', 1763721783, NULL, NULL),
(2, 'Второй пост', 'Текст второго поста', 1763721784, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `bl_users`
--

CREATE TABLE `bl_users` (
  `id` int UNSIGNED NOT NULL,
  `type` tinyint UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` char(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `bl_users`
--

INSERT INTO `bl_users` (`id`, `type`, `name`, `login`, `password`) VALUES
(1, 0, 'Макс', 'maks', '202cb962ac59075b964b07152d234b70'),
(2, 0, 'Ольга', 'olga', '81dc9bdb52d04dc20036dbd8313ed055'),
(3, 0, 'Вася', 'vasya', '827ccb0eea8a706c4c34a16891f84e7b');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `bl_comments`
--
ALTER TABLE `bl_comments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `bl_posts`
--
ALTER TABLE `bl_posts`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `bl_users`
--
ALTER TABLE `bl_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `bl_comments`
--
ALTER TABLE `bl_comments`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `bl_posts`
--
ALTER TABLE `bl_posts`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `bl_users`
--
ALTER TABLE `bl_users`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
