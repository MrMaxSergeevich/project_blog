<?php
require_once 'src/Base.php';

$content = 'registration';
$title_site = 'Регистрация';
if (isset($request->regist_user)) {
    $name = $request->name?? '';
    $login = $request->login?? '';
    if (isset($request->password) && is_string($request->password)) {
        $password = md5($request->password.SECRET);
    }
    if (empty($name) || empty($login) || empty($password)) echo  "<p style='color: red'>Пустые поля</p>";
    else {
        $login_exist = $db->getRowByWhere('users', '`login` = ?', [$login]);
        if ($login_exist) {
            echo "<p style='color: red'>Логин уже занят. Введите другой</p>";
        }
        else { 
            $db->insert('users', [$name, $login, $password]);
            echo "<p style='color: green'>Успешная регистрация!</p>";
        }
    } 
}

require_once 'html/main.php';