<?php
require_once 'src/Base.php';

$title_site = 'Блог';
$content = 'index';

$posts = $db->getCountRows('posts');
$comments = $db->getCountRows('comments');
$users = $db->getCountRows('users');

$titles = $db->getRowsByFields('posts', ['title', 'id']);

foreach($titles as $title) {
    $post_comments[] = $db->getCountRows('comments', '`post_id` = ?', [$title['id']]);
}

require_once 'html/main.php';
