<?php
require_once 'Config.php';

class Request {
    private array $data;

    public function __construct() {
        $this->data = $this->xss($_REQUEST);
    }

    private function xss(array|string $data): array|string {
        if (is_array($data)) {
            $arr = [];
            foreach($data as $key => $value) {
                $arr[$key] = $this->xss($value);
            }
            return $arr;
        }
        return trim(htmlspecialchars($data));
    }

    public function __get(string $name) : mixed {
        if (isset($this->data[$name])) return $this->data[$name];
        return false;
    }

    public function __isset(string $name): bool {
        return isset($this->data[$name]);
    }
}