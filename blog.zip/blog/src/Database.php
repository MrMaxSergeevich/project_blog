<?php
require_once 'Config.php';
class Database {
    private $pdo;
    private static $db;

    private function __construct() {
        try {
            $this->pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
        }
        catch (PDOException $e) {
            echo 'Ошибка подключения к базе данных: '.$e->getMessage();
        }
    }

    public static function getDBO() {
        if (!self::$db) self::$db = new Database();
        return self::$db;
    }

    public function getCountRows (string $table_name, string $where = '', array $values = []) {
        $sql = 'SELECT COUNT(`id`) FROM '.$this->getTableName($table_name);
        if ($where) $sql .= " WHERE $where";
        $query = $this->pdo->prepare($sql);
        $query->execute($values);
        return $query->fetchColumn();
    }

    private function getTableName($table_name): string {
        return '`'.DB_PREFIX.$table_name.'`';
    }

    public function getRows (string $table_name, string $where = '', array $values = [], string $order_by = ''): array {
        $sql = 'SELECT * FROM '.$this->getTableName($table_name);
        if ($where) $sql .= " WHERE $where";
        if ($order_by) $sql .= " ORDER BY $order_by";
        $query = $this->pdo->prepare($sql);
        $query->execute($values);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    // public function getRowsInnerJoin (string $table_name, string $innerjoin = '', string $where = '', array $values = [], string $order_by = ''): array {
    //     $sql = 'SELECT * FROM '.$this->getTableName($table_name);
    //     if ($innerjoin) $sql .= ", INNER JOIN $innerjoin";
    //     if ($where) $sql .= " WHERE $where";
    //     if ($order_by) $sql .= " ORDER BY $order_by";
    //     $query = $this->pdo->prepare($sql);
    //     $query->execute($values);
    //     return $query->fetchAll(PDO::FETCH_ASSOC);
    // }

    public function getRowsByFields (string $table_name, array $fields = [], string $where = '', array $values = [], string $order_by = ''): array {
        $field = $this->arrayToString($fields);
        $sql = "SELECT $field FROM ".$this->getTableName($table_name);
        if ($where) $sql .= " WHERE $where";
        if ($order_by) $sql .= " ORDER BY `$order_by`";
        $query = $this->pdo->prepare($sql);
        $query->execute($values);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    private function arrayToString(array $arr): string {
        $arr_filter = array_filter($arr, fn($value)=> $value !== NULL && $value !== '');
        $arr_string = array_map(callback: 'strval', array: $arr_filter);
        return implode(',', $arr_string);
    }

    public function getRowByWhere (string $table_name, string $where, array $values = []): array {
        $sql = 'SELECT * FROM '.$this->getTableName($table_name)." WHERE $where";
        $query = $this->pdo->prepare($sql);
        $query->execute($values);
        $result = $query->fetch(PDO::FETCH_ASSOC);
        if ($result) return $result;
        return [];
    }
    
    public function getRowById(string $table_name, int $id): array {
        return $this->getRowByWhere($table_name, 'id = ?', [$id]); 
    }

    public function getRowsIn(string $table_name, array $ids) : array {
        $in = str_repeat('?,', count($ids) - 1).'?';
        $sql = 'SELECT * FROM '.$this->getTableName($table_name)." WHERE `id` IN $in";
        $query = $this->pdo->prepare($sql);
        $query->execute($ids);
        $result = [];
        foreach($query->fetchAll() as $row) {
            $result[$row['id']] = $row;
        }
        if ($result) return $result;
        return [];
    }

    public function update(string $table_name, array $fields, array $values, string  $where = '', array $where_values = [])  {
        $sql = 'UPDATE '.$this->getTableName($table_name)." SET ";
        foreach($fields as $field) {
            $sql .= "$field = ?,";
        }
        $sql = substr($sql, 0, -1);
        if ($where) $sql .= " WHERE $where";
        $query = $this->pdo->prepare($sql);
        $query->execute(array_merge($values, $where_values));
    }

    // INSERT INTO `bl_users` (`name`, `login`, `password`) VALUES ('Михаил', 'michel', MD5('123456'));

    public function insert(string $table_name, array $fields = [], array $values = [])  {
        $field_list = '`'.implode('`,`', $fields).'`';
        $placeholders = str_repeat('?,', count($values) - 1).'?';
        $sql = 'INSERT INTO '.$this->getTableName($table_name)." ($field_list) VALUES ($placeholders)";
        // echo $sql;
        $query = $this->pdo->prepare($sql);
        $result = $query->execute($values);
        if ($result) return $result;
        return[];
    }

    public function __destruct() {
        $this->pdo = null;
    }
}