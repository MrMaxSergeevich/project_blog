<?php
require_once 'src/Base.php';

$id = $request->id?? 0;
if (is_numeric($id)) {
    $post = $db->getRowById('posts', $id);
    $comments = $db->getRows('comments', '`post_id` = ?', [$id]);
    $users = [];
    foreach ($comments as $comment) {
        $users[] = $db->getRowById('users', $comment['user_id']);
    }
    // print_r($users);
    // echo '<br />';
    // print_r($post);
    // echo '<br />';
    // print_r($auth_user);
    // echo '<br />';
    // echo time();
    if ($post) {
        $content = 'post';
        $title_site = $post['title'];
        // print_r($_REQUEST);
        $send_comment = $request->send_comment?? false;
        if ($send_comment) {
            $new_comment = $request->new_comment?? '';
            $time = time();
            $db->insert('comments', ['user_id', 'post_id', 'comment', 'time_comment'], [$auth_user['id'], $post['id'], $new_comment, $time]);

            header("Location: post.php?id=".$post['id']);
        }

        require_once 'html/main.php';
        exit;
    }
}
logout_404();