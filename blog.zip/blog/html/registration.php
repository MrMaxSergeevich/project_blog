<h1>Регистрация нового пользователя</h1>
<p>Введите свои персональные данные</p>
<form name="form_regist" action="" method="post">
    <p>
        <label for="name">Имя: </label>
        <input type="text" name="name" />
    </p>
    <p>
        <label for="login">Логин: </label>
        <input type="text" name="login" />
    </p>
    <p>
        <label for="password">Пароль: </label>
        <input type="password" name="password" />
    </p>
    <p>
        <input type="submit" name="regist_user" value="Зарегистрироваться" />
    </p>
</form>