<!DOCTYPE html>
<html lang="ru">
<head>
    <title><?=$title_site?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
    <div id="left">
        <?php if ($auth_user) { ?>
            <p>Здравствуйте, <?= $auth_user['name']?>!</p>
            <?php } else { ?>
            <div>
                <?php if ($error) { ?>
                    <p style="color:red">Неверные логин/пароль</p>
                <?php } ?>
                <h4>Авторизация</h4>
                <form action="" name="auth_form" method="post">
                <p>
                    <label>Логин: </label>
                    <input type="text" name="login" />
                </p>    
                <p>
                    <label>Пароль: </label>
                    <input type="password" name="password" />
                </p>
                <p>
                    <input type="submit" name="auth" value="Войти на сайт" />
                </p>       
                </form>
            </div>
        <?php } ?>
        <br />
        <h4>Меню сайта</h4>
        <ul>
            <li>
                <a href="index.php">Главная</a>
            </li>
            <li>
                <a href="autor.php">Об авторе блога</a>
            </li>
            <?php if (!$auth_user) { ?>
            <li>
                <a href="registration.php">Регистрация</a>
            </li>
            <?php } ?>
             <?php if ($auth_user) { ?>
            <li>
                <a href="?<?php echo http_build_query(array_merge($_GET, ['logout' => 1])) ?>">Выход</a>
            </li>
            <?php } ?>
            <br />
        </ul>
    </div>
    <div id="right"><?php require_once "html/$content.php" ?></div>
</body>
</html>
<style>
    #left {
        float: left;
    }

    #right {
        margin-left: 300px;
    }
</style>