<h1><?=$post['title']?></h1>
<p><?= $post['discription']?></p>
<br />
<h4>Комментарии</h4>
<?php if ($auth_user) { ?>
    <form name="send_comment" action="" method="post">
        <textarea name="new_comment" placeholder="Введите Комментарий"></textarea> 
        <br />
        <input type="submit" name="send_comment" value="Комментировать" />
    </form>
<?php } else { ?> 
    <p><i>Комментировать могут только авторизованные пользователи</i></p>
<?php } ?>
<?php if ($comments) { ?>
    <ul>
        <?php foreach($comments as $k => $v) { ?>
            <li>
                <?= date(DATE_FORMAT, $v['time_comment']) ?> Пользователь <?= $users[$k]['login'] ?>: 
                <br />
                <?= $v['comment'] ?>
                <br />
                <br />
            </li>
        <?php } ?>
     </ul>
<?php } ?>