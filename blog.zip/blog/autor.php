<?php
require_once 'src/Base.php';

$title_site = 'Об авторе';
$content = 'autor';

$posts = $db->getCountRows('posts');
$comments = $db->getCountRows('comments');
$users = $db->getCountRows('users');

require_once 'html/main.php';